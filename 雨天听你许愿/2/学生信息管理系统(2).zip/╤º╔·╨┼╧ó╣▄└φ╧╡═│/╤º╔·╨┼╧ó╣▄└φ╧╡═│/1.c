#include <stdio.h>
int one(int x)
{
	return (x*x*x);
}
int one1(int y)
{
	return (y*y*y);
}
int one2(int z)
{
	return (z*z*z);
}
int Sum(int x1,int y1,int z1)
{
	return(one(x1)+one1(y1)+one2(z1));
}
main()
{
	int a,b,c;
	printf("������������:\n");
	scanf("%d%d%d",&a,&b,&c);
	printf("%d\n",Sum(a,b,c));

}
	
	 