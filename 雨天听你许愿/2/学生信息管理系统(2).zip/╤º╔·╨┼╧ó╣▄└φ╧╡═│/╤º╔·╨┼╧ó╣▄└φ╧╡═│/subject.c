#include <stdio.h>
#include "Add_records.h"


void main()
{
	while(1)
	{
		int choice;
		read_1();
		title();
		printf("��ѡ��1-7��");
		scanf("%d",&choice);
		getchar();
		switch(choice)
		{
			case 1:
				lnput();
				break;
			case 2:
				query();
				break;
			case 3:
				modify_3();
				modify_4();
				break;
			case 4:
				Delete_1();
				break;
			case 5:
				consult_1();
				break;
			case 6:
				sort();
				break;
		}
		writein();
	}
}
